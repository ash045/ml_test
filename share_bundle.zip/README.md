# crypto_ml_signals — Leak-Proof ML Trading Signals (Minute-Bar Crypto)

End-to-end pipeline per spec: data → bars → features → labels → purged+embargoed walk-forward (nested-ish) →
models (Logit / LightGBM / CatBoost) → probability calibration → out-of-fold (OOF) probs → ensembling (stub) →
EV mapping (with liquidity gating) → hysteresis/cool-downs → backtesting (after-cost, liquidity-aware).

## Quickstart (PowerShell)
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
$env:PYTHONPATH=(Resolve-Path .\src).Path

# Put your CSV at data/raw/cleaned_file.csv with columns:
# timestamp (UTC), open, high, low, close, volume, trades

python scripts/train.py --config configs/config.yaml
python scripts/train_models.py --config configs/config.yaml
python scripts/run_backtest.py --config configs/config.yaml
```

## Notes
- `trades` is **required** and used in features, tick bars, liquidity gate, and slippage model.
- All rolling ops are strictly causal (no centered windows, no filtfilt).
- Costs: fees + spread + volatility/size impact with trades-based liquidity penalty.

## Optional: Multi-timeframe & Ensemble
To build datasets and OOF predictions for multiple timeframes and ensemble them:
```powershell
# Build datasets
python scripts/train.py --config configs/config.yaml --timeframe 1min
python scripts/train.py --config configs/config.yaml --timeframe 5min
python scripts/train.py --config configs/config.yaml --timeframe 15min

# Train per-timeframe models (writes artifacts/oof_probs_{tf}.csv and train reports)
python scripts/train_models.py --config configs/config.yaml --timeframe 1min
python scripts/train_models.py --config configs/config.yaml --timeframe 5min
python scripts/train_models.py --config configs/config.yaml --timeframe 15min

# Build ensemble probabilities
python scripts/build_ensemble.py --config configs/config.yaml

# Backtest (will auto-use ensemble if present)
python scripts/run_backtest.py --config configs/config.yaml
```

## Optional: Performance breakdowns
```powershell
python scripts/report_performance.py --config configs/config.yaml
```
Produces `perf_by_vol.csv` and `perf_by_trades.csv` in `reports/`.
