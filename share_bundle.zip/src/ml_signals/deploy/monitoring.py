# Monitoring hooks for live calibration and latency.
